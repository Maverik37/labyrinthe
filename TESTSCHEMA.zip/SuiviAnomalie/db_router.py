from .models import *

ROUTED_MODELS=[
    'Socle',
    'Artefact',
    'Lot',
]

class MyDBRouter(object):
    def db_for_read(self, model, **hints):
        """
        Attempts to read auth and contenttypes models go to auth_db.
        """
        if model in ROUTED_MODELS:
            return "suivianomalie_db"
        return None

    def db_for_write(self, model, **hints):
        """
        Attempts to write auth and contenttypes models go to auth_db.
        """
        if model in ROUTED_MODELS:
            return "suivianomalie_db"
        return None