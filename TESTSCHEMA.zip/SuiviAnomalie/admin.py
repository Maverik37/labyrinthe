from django.contrib import admin

from .models import Category, ListeAno


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'c_name')


@admin.register(ListeAno)
class ListeAnoAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'l_mantis',
        'l_description',
        'l_contexte',
        'l_category',
        'l_trigramme',
        'l_reception_date',
        'l_affectation_date',
        'l_validation_date',
        'l_escalated',
    )
    list_filter = (
        'l_contexte',
        'l_category',
        'l_trigramme',
        'l_reception_date',
        'l_affectation_date',
        'l_validation_date',
        'l_escalated',
    )

