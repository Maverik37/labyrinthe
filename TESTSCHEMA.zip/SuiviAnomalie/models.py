from django.db import models
from Inventaire.models import *

class Category(models.Model):
    c_name = models.CharField(max_length=50,verbose_name="Type")

    def __str__(self):
        return self.c_name
    
    class Meta:
        managed= True
        db_table = 'suivianomalie_db\".\"Category'

class ListeAno(models.Model):
    l_mantis = models.IntegerField(verbose_name="N° mantis")
    l_description = models.TextField(max_length=350,verbose_name="description")
    l_contexte = models.ForeignKey(Contexte,on_delete=models.CASCADE,related_name="c_contexte",verbose_name="Contexte",blank=True,null=True)
    l_category = models.ForeignKey(Category,on_delete=models.CASCADE,related_name="c_category",verbose_name="Type")
    l_trigramme = models.ForeignKey(ProfilPoleEnv,on_delete=models.CASCADE,related_name="p_tri", verbose_name="Trigramme")
    l_reception_date = models.DateField(auto_now=False, verbose_name="Date de réception",blank=True,null=True)
    l_affectation_date = models.DateField(auto_now=False, verbose_name="Date d'affectation'",blank=True,null=True)
    l_validation_date = models.DateField(auto_now=False, verbose_name="Date de validation",blank=True,null=True)
    l_escalated = models.BooleanField(default=False,verbose_name="Escaladée")

    def __str__(self):
        return str(self.l_mantis)+"_"+self.l_contexte+"_"+self.l_category.c_name
    
    class Meta:
        managed= True
        db_table = 'suivianomalie_db\".\"ListeAno'