from django.urls import path
from . import views

app_name = 'SuiviAnomalie'

urlpatterns= [
	path('',views.index, name="suiviano_index"),
]