from django.contrib import admin
from .models import *

@admin.register(ApplicationDjango)
class ApplicationDjangoAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'a_name',
        'a_portail_name',
        'a_views_name',
        'a_url_home',
    )
