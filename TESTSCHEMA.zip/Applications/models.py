from django.db import models

class ApplicationDjango(models.Model):
    a_name = models.CharField(max_length=100,verbose_name="Nom")
    a_portail_name = models.CharField(max_length=100,verbose_name="Nom portail")
    a_views_name = models.CharField(max_length=100,verbose_name="Views name")
    a_url_home = models.CharField(max_length=100,verbose_name="Url home")

    def __str__(self):
        return self.a_name+"_"+self.a_portail_name
    
    class Meta:
        managed= True
        db_table = 'django\".\"ApplicationDjango'
