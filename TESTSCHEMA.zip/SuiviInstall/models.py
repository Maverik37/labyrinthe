from django.db import models
from Inventaire.models import *

class Statut(models.Model):
    s_name = models.CharField(max_length=100,verbose_name="Statut")

    def __str__(self):
        return self.s_name
    
    class Meta:
        managed= True
        db_table = 'suiviinstall_db\".\"Statut'

class SuiviInstall(models.Model):
    su_mantis = models.IntegerField(verbose_name="N°")
    su_contexte = models.ForeignKey(Contexte,on_delete=models.CASCADE,related_name="c_context",verbose_name="Contexte")
    su_reception_date = models.DateField(verbose_name="Date réception",blank=True,null=True)
    su_statut = models.ForeignKey(Statut,on_delete=models.CASCADE,related_name="s_statut",verbose_name="Statut")
    su_analyse_date = models.DateField(verbose_name="Date début d'analyse",blank=True,null=True)
    su_is_auth = models.BooleanField(default=False,verbose_name="FV")
    su_install_date = models.DateField(verbose_name="Date fin installation",blank=True,null=True)
    su_test_date = models.DateField(verbose_name="Date début des test",blank=True,null=True)
    su_desired_delivery_date = models.DateField(verbose_name="livraison souhaitée",blank=True,null=True)
    su_delivery_date = models.DateField(verbose_name="Livraison",blank=True,null=True)
    su_penv_user = models.ForeignKey(ProfilPoleEnv,on_delete=models.CASCADE, related_name="su_trigramme", verbose_name="Acteur PENV")

    def __str__(self):
        return str(self.su_mantis)+"_"+self.su_contexte+"_"+self.su_statut+"_"+self.su_penv_user
    
    class Meta:
        managed= True
        db_table = 'suiviinstall_db\".\"SuiviInstall'