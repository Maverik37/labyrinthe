from django.shortcuts import render

def index_install(request):
    return render(request,'SuiviInstall/index_tab_install.html')

def index_carto(request):
    return render(request,'SuiviInstall/index_cartographie.html')
