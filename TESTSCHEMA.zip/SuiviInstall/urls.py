from django.urls import path
from . import views

app_name = 'SuiviInstall'

urlpatterns= [
	path('',views.index_install, name="suiviinstall_index_tab"),
    path('cartographie/',views.index_carto, name="suiviinstall_carto"),
]