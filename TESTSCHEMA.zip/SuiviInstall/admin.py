from django.contrib import admin
from .models import Statut, SuiviInstall


@admin.register(Statut)
class StatutAdmin(admin.ModelAdmin):
    list_display = ('id', 's_name')


@admin.register(SuiviInstall)
class SuiviInstallAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'su_mantis',
        'su_contexte',
        'su_reception_date',
        'su_statut',
        'su_analyse_date',
        'su_is_auth',
        'su_install_date',
        'su_test_date',
        'su_desired_delivery_date',
        'su_delivery_date',
        'su_penv_user',
    )
    list_filter = (
        'su_contexte',
        'su_reception_date',
        'su_statut',
        'su_analyse_date',
        'su_is_auth',
        'su_install_date',
        'su_test_date',
        'su_desired_delivery_date',
        'su_delivery_date',
        'su_penv_user',
    )

