#!/bin/env  python3
import os
import sys
import django
import csv,re
#Configuration pour pouvoir importer les modèles django
sys.path.append('/home/fourbasse/scripts/DJANGO/SuiviPoleEnv/SuiviPoleEnv/')
os.environ["DJANGO_SETTINGS_MODULE"] = "SuiviPoleEnv.settings"
django.setup()


#Import des models

from Inventaire.models import *

file_qual="qualifieurs.csv"
file_contexte="contextes.csv"

#On va ajouter d'abord les qualifieurs 
with open(file_qual,newline='') as csvfile:
    data = csv.DictReader(csvfile , delimiter=';',quotechar='|')
    for row in data:
        value = row['Qualifieurs']
        #On va checker si le qualifieur est présent ou non
        try:
            qs_qual = Qualifieur.objects.get(q_name=value)
        except Exception as e:
            #si l'exception est que le qualifieur existe pas , ba on l'ajoute en base dans le except
            if e.args[0] == "Qualifieur matching query does not exist.":
                #On crée un objet Qualifieur
                obj_new_qual = Qualifieur()
                obj_new_qual.q_name = value
                try:
                    obj_new_qual.save()
                except Exception as save_err:
                    print(save_err)

#On ajoute les contextes avec leur qualifieurs maintenant
print("Environnement\t|\tQualifieurs")
with open(file_contexte, newline='') as csvfile:
    data = csv.DictReader(csvfile, delimiter=';', quotechar='|')
    for row in data:
        contexte_value = row['Contexte']
        quali_value = row['Qualifieurs']
        print(contexte_value,quali_value)
        try:
            qs_contexte = Contexte.objects.get(c_name = contexte_value)
            
        except Exception as e:
            if e.args[0] == "Contexte matching query does not exist.":
                #on va créer le contexte
                try:
                    obj_context = Contexte()
                    obj_context.c_name = contexte_value
                    #on récupère l'objet du qualifieur s'il est pas vide
                    if quali_value != '':
                        obj_qualifieurs = Qualifieur.objects.get(q_name = quali_value)
                        obj_context.c_qualifier = obj_qualifieurs
                    else:
                        print('qualifieur vide')
                    obj_context.save()
                except Exception as err_save:
                    print(err_save,quali_value)
