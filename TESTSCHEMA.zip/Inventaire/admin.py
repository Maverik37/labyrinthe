from django.contrib import admin
from .models import *


@admin.register(Socle)
class SocleAdmin(admin.ModelAdmin):
    list_display = ('id', 's_name')


@admin.register(Artefact)
class ArtefactAdmin(admin.ModelAdmin):
    list_display = ('id', 'a_name', 'a_version')


@admin.register(Lot)
class LotAdmin(admin.ModelAdmin):
    list_display = ('id', 'l_name', 'l_version', 'l_socle')
    list_filter = ('l_socle',)
    raw_id_fields = ('l_artefacts',)


@admin.register(Qualifieur)
class QualifieurAdmin(admin.ModelAdmin):
    list_display = ('id', 'q_name')


@admin.register(Contexte)
class ContexteAdmin(admin.ModelAdmin):
    list_display = ('id', 'c_name', 'c_qualifier')
    list_filter = ('c_qualifier',)


@admin.register(ProfilPoleEnv)
class ProfilPoleEnvAdmin(admin.ModelAdmin):
    list_display = ('id', 'p_user', 'p_trigramme')
    list_filter = ('p_user',)

