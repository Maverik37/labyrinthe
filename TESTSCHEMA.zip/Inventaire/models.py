from django.db import models
from django.contrib.auth.models import User

class Socle(models.Model):
    s_name = models.CharField(max_length=40,verbose_name="Nom")

    def __str__(self):
        return self.s_name
    
    class Meta:
        managed= True
        db_table = 'inventaire_db\".\"Socle'

class Artefact(models.Model):
    a_name = models.CharField(max_length=40,verbose_name="Nom")
    a_version = models.CharField(max_length=20,verbose_name="Version")
    def __str__(self):
        return self.s_name+"_"+self.a_version
    
    class Meta:
        managed= True
        db_table = 'inventaire_db\".\"Artefact'

class Lot(models.Model):
    l_name = models.CharField(max_length=40,verbose_name="Nom")
    l_version = models.CharField(max_length=20,verbose_name="Version")
    l_artefacts = models.ManyToManyField(Artefact, related_name="a_artefact",blank=True)
    l_socle = models.ForeignKey(Socle, on_delete=models.CASCADE, related_name="s_socle", blank=True, null=True)


    def __str__(self):
        return self.l_name+"_"+self.l_version
    
    class Meta:
        managed= True
        db_table = 'inventaire_db\".\"Lot'

class Qualifieur(models.Model):
    q_name = models.CharField(max_length=40, verbose_name="Nom")

    def __str__(self):
        return self.q_name
    
    class Meta:
        managed= True
        db_table = 'inventaire_db\".\"Qualifieur'

class Contexte(models.Model):
    c_name = models.CharField(max_length=50,verbose_name="Nom")
    c_qualifier = models.ForeignKey(Qualifieur, on_delete=models.CASCADE, blank=True,null=True)

    def __str__(self):

        return self.c_name #+"_"+self.c_qualifier.q_name
    class Meta:
        managed= True
        db_table = 'inventaire_db\".\"Contexte'

class ProfilPoleEnv(models.Model):
    p_user = models.ForeignKey(User,on_delete=models.CASCADE,blank=True,null=True,verbose_name="User")
    p_trigramme = models.CharField(max_length=3,verbose_name="Trigramme")

    def __str__(self):
        return self.p_trigramme
    class Meta:
        managed= True
        db_table = 'inventaire_db\".\"ProfilPoleEnv'